<?php
//__NM__Para saber si una URL cualquiera está disponible__NM__FUNCTION__NM__//
function fSiExisteURL($URL)
{
        $c = curl_init();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_URL, $URL);
        $contents = curl_exec($c);
        curl_close($c);

        if ($contents) return true;
            else return false;
}
?>