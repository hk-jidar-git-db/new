<?php
//__NM__Para crear una tabla de lista de registros de una tabla en html__NM__FUNCTION__NM__//
function fListaHtml($tabla,$ancho,$columnas){
	
	echo "
	<style type='text/css'>
	table{

		font-size:12px;
		font-family:Arial;
		border-collapse: collapse;
		width: ".$ancho."%;
	}

	tr:nth-of-type(odd) { 
	  	background: #fff; 
	}
	th { 
	  background: #333; 
	  color: white; 
	  font-weight: bold; 
	}
	td, th { 
	  	padding: 6px; 
	  	border: 1px solid #ccc; 
	  	text-align: left; 
	}
	</style>";
	
	//modo de consulta
	sc_set_fetchmode(1); 
	
	$sql = "select * from ".$tabla;
	
	//consultamos con select
	sc_select(my_data, $sql); 
	
	if(!empty($my_data)){
		
		//centramos
		echo "<center>";
		
		//creamos la tabla
		echo "<table>";
		
		//titulos
		echo "<tr>";
		for($a=0;$a<count($columnas);$a++){
			
			echo "<th>".$columnas[$a]."</th>";
		}
		echo "</tr>";
	
		//recorremos el resultado
		while (!$my_data->EOF){ 
			
			//inicio fila
			echo "<tr>";

			for($i=0;$i<count($my_data->fields);$i++){

				echo "<td>".$my_data->fields[$i]."</td>"; 	

			}

			//siguiente registro
			$my_data->MoveNext(); 
			
			//fin fila
			echo "</tr>";
		} 

		//cerramos la conexion
		$my_data->Close(); 
		
		//finalizamos la tabla
		echo "</table>";
		
		//fin centro
		echo "</center>";
		
	}else{
		
		echo "La siguiente tabla no existe o no tiene registros: ".$tabla;
	}
}
?>