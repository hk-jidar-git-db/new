<?php
//__NM__prueba__NM__FUNCTION__NM__//
function saluda($nombre){
	echo "Hola $nombre";
	
}
?>