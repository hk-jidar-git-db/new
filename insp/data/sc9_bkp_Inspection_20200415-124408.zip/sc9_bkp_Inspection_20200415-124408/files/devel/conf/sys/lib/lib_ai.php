<?php
//__NM__libreria aibc__NM__FUNCTION__NM__//
	
function saludo($quien){
	
	echo "Hola, $quien";
	}
	
?>